import com.eduardoozika.entity.Celular;
import com.eduardoozika.entity.Estudante;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class sistemaTest {
    @Test
    @DisplayName("Cadastra um estudante")
    void DeveriaCadastrarEstudante(){
        LocalDate date = LocalDate.parse("22-07-2022", DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        Celular celular = new Celular("63981371158");
        List<Celular> celulares = new ArrayList<>();
        celulares.add(celular);
        Estudante estudante = new Estudante("Eduardo", date,"704 sul","eduardo.vicente@estudante.ifto.edu.br",celulares);

    }
}
